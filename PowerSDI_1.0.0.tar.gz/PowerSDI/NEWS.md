# PowerSDI 1.0.0

# PowerSDI 0.1.0

* Initial CRAN submission.
